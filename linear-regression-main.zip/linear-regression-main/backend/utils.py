import numpy as np

def model(x, w, b):
    h_hat = w.T * x + b
    return h_hat

def loss(y_true, y_pred, m):
    constant = 1 / (2 * m)
    sqrd_err = (y_true - y_pred) ** 2
    j = constant * np.sum(sqrd_err)
    return j

def dow_j_dow_w(x, y_true, y_pred, m):
    constant = 1 / m
    err = y_pred - y_true
    sum_err = np.sum(err*x) 
    return constant * sum_err 

def dow_j_dow_b(y_true, y_pred, m):
    constant = 1 / m
    err = y_pred - y_true
    sum_err = np.sum(err) 
    return constant * sum_err 
