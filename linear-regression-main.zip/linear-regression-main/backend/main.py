import numpy as np
import pandas as pd
from utils import model, loss, dow_j_dow_w, dow_j_dow_b

df = pd.read_csv("C:/Users/muthuvu/3D Objects/Build/linear-regression-main/backend/dataset/train_dataset.csv")

w = np.random.rand(1)
b = np.ones(1)
n_iter = 200
alpha = 0.001

X = df["feature_0"].values.reshape(-1, 1)
y = df["target"].values
m = X.shape[0]

l = model(X, w, b)
print("X", X.shape)
print(model(X, w, b))
print(model(X, w, b).shape)

# training loop
for i in range(1, n_iter):
    # model calling
    y_pred_arr = model(X, w, b)
    
    # calculate loss
    l = loss(y, y_pred_arr, m)

    if i % 10 == 0:
        print(f"Loss @ {i}:", l)

    # update weights
    w = w - alpha * dow_j_dow_w(X, y, y_pred_arr, m)
    #print(dow_j_dow_w(X, y, y_pred_arr, m))
    b = b - alpha * dow_j_dow_b(y, y_pred_arr, m)

print("Final prediction:", l)
print("Final w:", w)
print("Final b:", b)